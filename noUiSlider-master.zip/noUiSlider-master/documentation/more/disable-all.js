// To disable
slider.noUiSlider.disable();

// To re-enable
slider.noUiSlider.enable();

// To disable one handle
slider.noUiSlider.disable(1);
